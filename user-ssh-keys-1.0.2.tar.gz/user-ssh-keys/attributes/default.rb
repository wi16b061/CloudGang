default['user_ssh_keys']['data_bag'] = 'ssh_keys'
default['user_ssh_keys']['users'] = []
